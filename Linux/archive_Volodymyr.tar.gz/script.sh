#!/bin/bash
#task 1
#
echo "Hello!"
echo "PWD -  $PWD"
pwd
echo "Date  "
date
echo "Error"
grep -rn "error" /var/log/ 2>/dev/null
echo "os-release"
cat /etc/os-release
cat /etc/os-release | wc -l
echo "last 5 lines"
cat /etc/os-release | tail -5
echo "Users and passward"
awk -F ":" '{print "User - ",$1," Home - ",$6}' /etc/passwd
echo "Скрипт успешно выполнен!"


